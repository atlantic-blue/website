"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const handler = async (event, context) => {
    console.log('Event: ', JSON.stringify(event));
    return {
        statusCode: 200,
        headers: {
            "Content-Type": "text/html",
        },
        body: `Hello world! ${new Date().toISOString()}`,
    };
};
exports.handler = handler;
