"use strict";
exports.id = 320;
exports.ids = [320];
exports.modules = {

/***/ "./src/server/lambdaHandler.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  createBody: () => (/* binding */ createBody),
  "default": () => (/* binding */ lambdaHandler)
});

// NAMESPACE OBJECT: ./src/components/Card/Card.scss
var Card_namespaceObject = {};
__webpack_require__.r(Card_namespaceObject);
__webpack_require__.d(Card_namespaceObject, {
  q: () => (card)
});

// NAMESPACE OBJECT: ./src/pages/Home/Body/Body.scss
var Body_namespaceObject = {};
__webpack_require__.r(Body_namespaceObject);
__webpack_require__.d(Body_namespaceObject, {
  SC: () => (body),
  oJ: () => (sectionAbout),
  Q7: () => (sectionClients),
  G: () => (sectionCta),
  eC: () => (sectionIntro),
  sh: () => (sectionProducts)
});

// NAMESPACE OBJECT: ./src/components/Dropdown/Dropdown.scss
var Dropdown_namespaceObject = {};
__webpack_require__.r(Dropdown_namespaceObject);
__webpack_require__.d(Dropdown_namespaceObject, {
  sq: () => (Dropdown_button),
  uQ: () => (container),
  AV: () => (menu),
  MH: () => (Dropdown_option)
});

// NAMESPACE OBJECT: ./src/components/Header/Header.scss
var Header_namespaceObject = {};
__webpack_require__.r(Header_namespaceObject);
__webpack_require__.d(Header_namespaceObject, {
  k: () => (header)
});

// NAMESPACE OBJECT: ./src/components/Footer/Footer.scss
var Footer_namespaceObject = {};
__webpack_require__.r(Footer_namespaceObject);
__webpack_require__.d(Footer_namespaceObject, {
  k: () => (footer)
});

// EXTERNAL MODULE: ./node_modules/react/index.js
var react = __webpack_require__("./node_modules/react/index.js");
// EXTERNAL MODULE: ./node_modules/react-dom/server.node.js
var server_node = __webpack_require__("./node_modules/react-dom/server.node.js");
// EXTERNAL MODULE: ./node_modules/react-router-dom/server.js
var server = __webpack_require__("./node_modules/react-router-dom/server.js");
// EXTERNAL MODULE: ./node_modules/react-helmet/es/Helmet.js
var Helmet = __webpack_require__("./node_modules/react-helmet/es/Helmet.js");
;// CONCATENATED MODULE: ./src/server/html.ts
var Html = function Html(_ref) {
  var htmlAttributes = _ref.htmlAttributes,
    bodyAttributes = _ref.bodyAttributes,
    head = _ref.head,
    body = _ref.body;
  return "\n        <!DOCTYPE html>\n        <html ".concat(htmlAttributes, ">\n\n        <head>\n            ").concat(head, "\n        </head>\n\n        <body ").concat(bodyAttributes, " id=\"main\">\n            ").concat(body, "\n        </body>\n\n        </html >\n    ");
};

// EXTERNAL MODULE: ./node_modules/react-router/dist/index.js
var dist = __webpack_require__("./node_modules/react-router/dist/index.js");
;// CONCATENATED MODULE: ./src/components/ConfigContext.tsx

var ConfigContext = /*#__PURE__*/(0,react.createContext)({});
var useConfig = function useConfig() {
  var config = (0,react.useContext)(ConfigContext);
  if (!config) {
    throw new Error("Configuration context not initialized!");
  }
  return config;
};

;// CONCATENATED MODULE: ./src/resourceStrings/types.ts
var ResourceStringLanguage = /*#__PURE__*/function (ResourceStringLanguage) {
  ResourceStringLanguage["ENGLISH"] = "en";
  ResourceStringLanguage["SPANISH"] = "es";
  ResourceStringLanguage["FRENCH"] = "fr";
  ResourceStringLanguage["PORTUGUESE"] = "pt";
  ResourceStringLanguage["RUSSIAN"] = "ru";
  return ResourceStringLanguage;
}({});
;// CONCATENATED MODULE: ./src/pages/Help.tsx


var HelpPage = function HelpPage() {
  return /*#__PURE__*/react.createElement("div", null, /*#__PURE__*/react.createElement(Helmet/* Helmet */.S, null, /*#__PURE__*/react.createElement("html", {
    lang: "es"
  }), /*#__PURE__*/react.createElement("title", null, "Help Page"), /*#__PURE__*/react.createElement("body", {
    className: "root help"
  })), "I am a help page");
};
/* harmony default export */ const Help = (HelpPage);
;// CONCATENATED MODULE: ./src/resourceStrings/en.ts
var resourceStringEn = {
  home: {
    section: {
      hero: {
        title: "Elevate Your Business with Tailored Software Solutions",
        description: "Transform Your Business with Innovative Software Development Solutions.",
        cta: "Learn More"
      },
      intro: {
        content: "Are you seeking exceptional software development services? Look no further than Atlantic Blue. Our dedicated team of skilled developers and engineers specializes in delivering high-quality, customized software solutions designed to meet your specific business needs. With a focus on innovation and efficiency, Atlantic Blue is the partner you need to bring your software ideas to life.Whether you're a startup or an established company, Atlantic Blue is committed to providing tailored software development services to help you stay ahead in the competitive tech industry. Contact us today to learn more about how we can help elevate your business with our expertise in software development."
      },
      products: {
        solutions: {
          imgAlt: "Customized Software Solutions",
          title: "Tailored Solutions for Your Business",
          description: "We understand the unique requirements of your business and offer personalized software solutions ensuring seamless integration and heightened efficiency."
        },
        methodology: {
          imgAlt: "Agile Development Methodology",
          title: "Agile Development Methodology",
          description: "Using agile methodologies, we deliver superior software solutions faster, guaranteeing adaptability and swift responses to market changes."
        },
        support: {
          imgAlt: "Expert Technical Support",
          title: "Expert Technical Support",
          description: "Our technical experts provide dedicated support throughout the software development lifecycle, ensuring smooth implementation and continuous maintenance."
        }
      },
      clients: {
        title: "Our Customers"
      },
      about: {
        title: "Atlantic Blue, Your Partner in Software Innovation",
        description: "Welcome to Atlantic Blue, a leading software development company in London, UK. We're committed to transforming ideas into reality with our extensive expertise and innovative solutions. \n\n At Atlantic Blue, we're passionate about crafting cutting-edge software that meets our clients' unique needs. Our collaborative team of skilled developers, designers, and strategists ensures exceptional results, driving business growth and success. Trust us to deliver reliable, scalable, and user-friendly tailored software solutions.",
        imgAlt: "screen"
      }
    }
  }
};
;// CONCATENATED MODULE: ./src/resourceStrings/es.ts
var resourceStringEs = {
  home: {
    section: {
      hero: {
        title: "Eleve su Negocio con Soluciones de Software Personalizadas",
        description: "Transforme su Negocio con Soluciones Innovadoras de Desarrollo de Software.",
        cta: "Más Información"
      },
      intro: {
        content: "¿Está en busca de servicios excepcionales de desarrollo de software? No busque más, confíe en Atlantic Blue. Nuestro equipo dedicado de desarrolladores y ingenieros especializados se enfoca en entregar soluciones de software personalizadas de alta calidad diseñadas para satisfacer sus necesidades específicas de negocio. Con un enfoque en la innovación y la eficiencia, Atlantic Blue es el socio que necesita para materializar sus ideas de software. Ya sea una startup o una empresa establecida, Atlantic Blue se compromete a proporcionar servicios de desarrollo de software adaptados para ayudarle a mantenerse a la vanguardia en la competitiva industria tecnológica. Contáctenos hoy mismo para conocer más sobre cómo podemos elevar su negocio con nuestra experiencia en desarrollo de software."
      },
      products: {
        solutions: {
          imgAlt: "Soluciones de Software Personalizadas",
          title: "Soluciones a Medida para su Negocio",
          description: "Entendemos los requisitos únicos de su negocio y ofrecemos soluciones de software personalizadas que garantizan una integración fluida y una mayor eficiencia."
        },
        methodology: {
          imgAlt: "Metodología de Desarrollo Ágil",
          title: "Metodología de Desarrollo Ágil",
          description: "Utilizando metodologías ágiles, ofrecemos soluciones de software superiores de manera más rápida, garantizando adaptabilidad y respuestas ágiles a los cambios del mercado."
        },
        support: {
          imgAlt: "Soporte Técnico Expert",
          title: "Soporte Técnico Expert",
          description: "Nuestros expertos técnicos brindan soporte dedicado a lo largo del ciclo de desarrollo de software, asegurando una implementación fluida y un mantenimiento continuo."
        }
      },
      clients: {
        title: "Nuestros Clientes"
      },
      about: {
        title: "Atlantic Blue, Su Socio en Innovación de Software",
        description: "Bienvenido a Atlantic Blue, una destacada empresa de desarrollo de software en Londres, Reino Unido. Estamos comprometidos con transformar ideas en realidad mediante nuestra amplia experiencia y soluciones innovadoras. \n\n En Atlantic Blue, nos apasiona crear software de vanguardia que satisfaga las necesidades únicas de nuestros clientes. Nuestro equipo colaborativo de desarrolladores, diseñadores y estrategas especializados asegura resultados excepcionales, impulsando el crecimiento y el éxito empresarial. Confíe en nosotros para ofrecer soluciones de software personalizadas confiables, escalables y fáciles de usar.",
        imgAlt: "pantalla"
      }
    }
  }
};
;// CONCATENATED MODULE: ./src/resourceStrings/fr.ts
var resourceStringFr = {
  home: {
    section: {
      hero: {
        title: "Élevez votre entreprise avec des solutions logicielles sur mesure",
        description: "Transformez votre entreprise avec des solutions innovantes de développement logiciel.",
        cta: "En savoir plus"
      },
      intro: {
        content: "Vous recherchez des services exceptionnels de développement logiciel ? Ne cherchez pas plus loin qu'Atlantic Blue. Notre équipe dévouée de développeurs et d'ingénieurs qualifiés se spécialise dans la fourniture de solutions logicielles personnalisées et de haute qualité conçues pour répondre à vos besoins spécifiques en affaires. Avec un accent sur l'innovation et l'efficacité, Atlantic Blue est le partenaire dont vous avez besoin pour concrétiser vos idées logicielles. Que vous soyez une start-up ou une entreprise établie, Atlantic Blue s'engage à fournir des services de développement logiciel sur mesure pour vous aider à rester en tête dans l'industrie technologique compétitive. Contactez-nous dès aujourd'hui pour en savoir plus sur comment nous pouvons aider à élever votre entreprise avec notre expertise en développement logiciel."
      },
      products: {
        solutions: {
          imgAlt: "Solutions logicielles personnalisées",
          title: "Solutions adaptées à votre entreprise",
          description: "Nous comprenons les exigences uniques de votre entreprise et proposons des solutions logicielles personnalisées garantissant une intégration sans faille et une efficacité accrue."
        },
        methodology: {
          imgAlt: "Méthodologie de développement agile",
          title: "Méthodologie de développement agile",
          description: "En utilisant des méthodologies agiles, nous fournissons des solutions logicielles supérieures plus rapidement, garantissant une adaptabilité et des réponses rapides aux changements du marché."
        },
        support: {
          imgAlt: "Support technique expert",
          title: "Support technique expert",
          description: "Nos experts techniques fournissent un support dédié tout au long du cycle de développement logiciel, garantissant une mise en œuvre fluide et une maintenance continue."
        }
      },
      clients: {
        title: "Nos clients"
      },
      about: {
        title: "Atlantic Blue, Votre partenaire en innovation logicielle",
        description: "Bienvenue chez Atlantic Blue, une société de développement logiciel de premier plan à Londres, Royaume-Uni. Nous nous engageons à transformer les idées en réalité avec notre vaste expertise et des solutions innovantes. \n\n Chez Atlantic Blue, nous sommes passionnés par la création de logiciels de pointe qui répondent aux besoins uniques de nos clients. Notre équipe collaborative de développeurs, de concepteurs et de stratèges qualifiés garantit des résultats exceptionnels, stimulant la croissance et le succès de l'entreprise. Faites-nous confiance pour fournir des solutions logicielles sur mesure fiables, évolutives et conviviales.",
        imgAlt: "écran d'ordinateur"
      }
    }
  }
};
;// CONCATENATED MODULE: ./src/resourceStrings/pt.ts
var resourceStringPt = {
  home: {
    section: {
      hero: {
        title: "Eleve Seu Negócio com Soluções de Software Personalizadas",
        description: "Transforme Seu Negócio com Soluções Inovadoras de Desenvolvimento de Software.",
        cta: "Saiba Mais"
      },
      intro: {
        content: "Você está em busca de serviços excepcionais de desenvolvimento de software? Não procure além da Atlantic Blue. Nossa equipe dedicada de desenvolvedores e engenheiros especializados se destaca na entrega de soluções de software personalizadas e de alta qualidade, projetadas para atender às suas necessidades específicas de negócio. Com foco em inovação e eficiência, a Atlantic Blue é o parceiro que você precisa para dar vida às suas ideias de software. Seja você uma startup ou uma empresa estabelecida, a Atlantic Blue está comprometida em fornecer serviços de desenvolvimento de software personalizados para ajudá-lo a se manter à frente na competitiva indústria de tecnologia. Entre em contato hoje mesmo para saber mais sobre como podemos elevar o seu negócio com a nossa expertise em desenvolvimento de software."
      },
      products: {
        solutions: {
          imgAlt: "Soluções de Software Personalizadas",
          title: "Soluções Personalizadas para o Seu Negócio",
          description: "Entendemos os requisitos únicos do seu negócio e oferecemos soluções de software personalizadas garantindo integração perfeita e eficiência elevada."
        },
        methodology: {
          imgAlt: "Metodologia de Desenvolvimento Ágil",
          title: "Metodologia de Desenvolvimento Ágil",
          description: "Usando metodologias ágeis, entregamos soluções de software superiores mais rapidamente, garantindo adaptabilidade e respostas ágeis às mudanças de mercado."
        },
        support: {
          imgAlt: "Suporte Técnico Especializado",
          title: "Suporte Técnico Especializado",
          description: "Nossos especialistas técnicos fornecem suporte dedicado ao longo do ciclo de desenvolvimento de software, garantindo implementação tranquila e manutenção contínua."
        }
      },
      clients: {
        title: "Nossos Clientes"
      },
      about: {
        title: "Atlantic Blue, Seu Parceiro em Inovação de Software",
        description: "Bem-vindo à Atlantic Blue, uma empresa líder em desenvolvimento de software em Londres, Reino Unido. Estamos comprometidos em transformar ideias em realidade com nossa vasta experiência e soluções inovadoras. \n\n Na Atlantic Blue, somos apaixonados por criar software de ponta que atenda às necessidades únicas de nossos clientes. Nosso time colaborativo de desenvolvedores, designers e estrategistas qualificados garante resultados excepcionais, impulsionando o crescimento e o sucesso empresarial. Confie em nós para oferecer soluções de software personalizadas confiáveis, escaláveis e fáceis de usar.",
        imgAlt: "tela"
      }
    }
  }
};
;// CONCATENATED MODULE: ./src/resourceStrings/ru.ts
var resourceStringRu = {
  home: {
    section: {
      hero: {
        title: "Поднимите свой бизнес с помощью индивидуальных программных решений",
        description: "Преобразуйте свой бизнес с помощью инновационных решений в области разработки программного обеспечения.",
        cta: "Узнать больше"
      },
      intro: {
        content: "Вы ищете исключительные услуги в области разработки программного обеспечения? Не ищите дальше, чем Atlantic Blue. Наша преданная команда опытных разработчиков и инженеров специализируется на предоставлении высококачественных индивидуальных программных решений, созданных для удовлетворения ваших конкретных бизнес-потребностей. С акцентом на инновации и эффективность, Atlantic Blue - это партнер, который вам нужен, чтобы воплотить ваши идеи в программное обеспечение. Независимо от того, являетесь ли вы стартапом или установленной компанией, Atlantic Blue готова предоставить индивидуальные услуги в области разработки программного обеспечения, чтобы помочь вам оставаться на шаг впереди в конкурентной технологической индустрии. Свяжитесь с нами сегодня, чтобы узнать больше о том, как мы можем помочь поднять ваш бизнес с помощью нашего опыта в разработке программного обеспечения."
      },
      products: {
        solutions: {
          imgAlt: "Индивидуальные программные решения",
          title: "Индивидуальные решения для вашего бизнеса",
          description: "Мы понимаем уникальные требования вашего бизнеса и предлагаем персонализированные программные решения, обеспечивающие безупречную интеграцию и повышенную эффективность."
        },
        methodology: {
          imgAlt: "Методология гибкой разработки",
          title: "Методология гибкой разработки",
          description: "Используя гибкие методологии, мы доставляем превосходные программные решения быстрее, гарантируя адаптивность и быстрые реакции на изменения на рынке."
        },
        support: {
          imgAlt: "Экспертная техническая поддержка",
          title: "Экспертная техническая поддержка",
          description: "Наши технические эксперты предоставляют высококвалифицированную поддержку на протяжении жизненного цикла разработки программного обеспечения, обеспечивая бесперебойную реализацию и непрерывное обслуживание."
        }
      },
      clients: {
        title: "Наши клиенты"
      },
      about: {
        title: "Atlantic Blue, ваш партнер в области программных инноваций",
        description: "Добро пожаловать в Atlantic Blue, ведущую компанию по разработке программного обеспечения в Лондоне, Великобритания. Мы привержены преобразованию идей в реальность благодаря нашему обширному опыту и инновационным решениям. \n\n В Atlantic Blue мы увлечены созданием передового программного обеспечения, которое удовлетворяет уникальным потребностям наших клиентов. Наша совместная команда опытных разработчиков, дизайнеров и стратегов обеспечивает исключительные результаты, стимулируя рост и успех бизнеса. Доверьтесь нам, чтобы получить надежные, масштабируемые и удобные в использовании индивидуальные программные решения.",
        imgAlt: "компьютерный экран"
      }
    }
  }
};
;// CONCATENATED MODULE: ./src/resourceStrings/index.ts
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == _typeof(i) ? i : String(i); }
function _toPrimitive(t, r) { if ("object" != _typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != _typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }






var resourceStrings = _defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty({}, ResourceStringLanguage.ENGLISH, resourceStringEn), ResourceStringLanguage.SPANISH, resourceStringEs), ResourceStringLanguage.FRENCH, resourceStringFr), ResourceStringLanguage.PORTUGUESE, resourceStringPt), ResourceStringLanguage.RUSSIAN, resourceStringRu);
;// CONCATENATED MODULE: ./src/components/Card/Card.scss
// Exports
var card = `Card___card___rqCLW`;

;// CONCATENATED MODULE: ./src/components/Card/Card.tsx
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }


var Card = function Card(props) {
  return /*#__PURE__*/react.createElement("div", {
    className: card
  }, /*#__PURE__*/react.createElement("div", {
    className: Card_namespaceObject.cardBackground
  }, /*#__PURE__*/react.createElement("img", _extends({}, props.img, {
    className: Card_namespaceObject.cardBackgroundImg
  }))), /*#__PURE__*/react.createElement("div", null, /*#__PURE__*/react.createElement("p", {
    className: Card_namespaceObject.cardTitle
  }, props.title), /*#__PURE__*/react.createElement("p", {
    className: Card_namespaceObject.cardDescription
  }, props.description)));
};

;// CONCATENATED MODULE: ./src/icons/dazn.tsx
function dazn_extends() { dazn_extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return dazn_extends.apply(this, arguments); }

var Dazn = function Dazn(props) {
  return /*#__PURE__*/react.createElement("svg", dazn_extends({}, props, {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 240 240"
  }), /*#__PURE__*/react.createElement("path", {
    d: "M147.74 82.91l7.716-25.964 7.906 25.964H147.74zm38.48 22.68l-20.253-61.28c-.451-1.351-.965-2.239-1.541-2.655-.581-.416-1.515-.628-2.798-.628H150.44c-1.287 0-2.232.228-2.845.675-.611.448-1.11 1.32-1.495 2.608l-20.444 61.28c-.259.323-.384.959-.384 1.925 0 1.484.899 2.222 2.7 2.222h8.389c.773 0 1.397-.032 1.879-.094.483-.063.868-.228 1.159-.487.29-.252.544-.644.772-1.155.224-.518.464-1.193.722-2.026l3.183-10.712h23.05l3.276 10.516c.259.903.514 1.61.773 2.128.255.51.546.91.867 1.202.322.29.706.47 1.158.534.447.062 1.028.094 1.734.094h8.97c1.798 0 2.7-.738 2.7-2.222 0-.448-.015-.755-.047-.911-.036-.165-.145-.503-.337-1.014zm-9.944 24.672h-6.463c-1.672 0-2.783.243-3.327.723-.546.486-.817 1.468-.817 2.945v36.377l-19.094-36.472c-.773-1.546-1.53-2.529-2.268-2.944-.741-.417-2.04-.629-3.905-.629h-5.98c-1.671 0-2.782.243-3.327.723-.546.486-.82 1.468-.82 2.945v61.374c0 1.485.255 2.459.772 2.946.514.478 1.606.722 3.277.722h6.561c1.668 0 2.778-.244 3.324-.722.545-.487.82-1.46.82-2.946v-36.48l19.094 36.574c.773 1.548 1.526 2.53 2.268 2.946.738.423 2.04.628 3.904.628h5.98c1.672 0 2.779-.244 3.328-.722.545-.487.82-1.46.82-2.946V133.93c0-1.477-.275-2.459-.82-2.945-.55-.48-1.656-.723-3.327-.723zm32.03-5.811l16.65 16.65v83.855H15.045v-83.869l16.634-16.634a6.297 6.297 0 0 0 0-8.906L15.044 98.913v-83.87h209.913v83.851l-16.65 16.651a6.297 6.297 0 0 0 0 8.906zM240 0H0v106.133L13.867 120 0 133.867V240h240V133.867L226.134 120 240 106.133V0zM106.703 184.687h-27.11l28.548-40.14c.449-.644.74-1.161.87-1.547.13-.384.193-.832.193-1.35v-7.72c0-1.477-.276-2.459-.823-2.945-.547-.48-1.662-.723-3.339-.723H63.823c-1.485 0-2.45.275-2.902.817-.452.55-.677 1.688-.677 3.432v5.788c0 1.735.225 2.882.677 3.424.452.55 1.417.824 2.902.824h25.445l-28.157 40.14c-.713.903-1.068 1.806-1.068 2.701v7.916c0 1.485.276 2.459.823 2.946.548.478 1.662.722 3.34.722h42.497c1.484 0 2.453-.275 2.906-.817.449-.55.677-1.689.677-3.432v-5.787c0-1.737-.228-2.875-.677-3.424-.453-.55-1.422-.825-2.906-.825zM94.084 82.328c0 2.64-.176 4.846-.53 6.613-.353 1.767-.93 3.204-1.734 4.296-.804 1.091-1.864 1.861-3.183 2.317-1.318.447-2.942.675-4.87.675h-7.906V54.535h7.907c3.665 0 6.298 1.084 7.907 3.235 1.605 2.153 2.41 5.71 2.41 10.665v13.893zm13.793-27.888c-2.252-4.57-5.32-7.947-9.21-10.13-3.892-2.191-8.793-3.283-14.707-3.283H64.19c-1.672 0-2.782.243-3.328.723-.545.486-.82 1.468-.82 2.945v61.374c0 1.485.275 2.458.82 2.946.546.478 1.656.722 3.328.722h22.178c10.481 0 17.65-4.469 21.508-13.414.898-2.057 1.526-4.13 1.88-6.228.353-2.089.529-4.743.529-7.955V69.111c0-3.668-.176-6.565-.53-8.686a22.045 22.045 0 0 0-1.879-5.985z",
    fill: "#fff",
    fillRule: "nonzero"
  }));
};

;// CONCATENATED MODULE: ./src/icons/peacock.tsx
function peacock_extends() { peacock_extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return peacock_extends.apply(this, arguments); }

var Peacock = function Peacock(props) {
  return /*#__PURE__*/react.createElement("svg", peacock_extends({}, props, {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    fill: "none",
    viewBox: "0 0 114 35",
    "aria-hidden": "true"
  }), /*#__PURE__*/react.createElement("use", {
    xlinkHref: "#pwob_a",
    fill: "#069de0"
  }), /*#__PURE__*/react.createElement("use", {
    xlinkHref: "#pwob_a",
    y: "-5.747",
    fill: "#6e55dc"
  }), /*#__PURE__*/react.createElement("use", {
    xlinkHref: "#pwob_a",
    y: "5.745",
    fill: "#05ac3f"
  }), /*#__PURE__*/react.createElement("use", {
    xlinkHref: "#pwob_a",
    y: "-11.492",
    fill: "#ef1541"
  }), /*#__PURE__*/react.createElement("use", {
    xlinkHref: "#pwob_a",
    y: "-17.239",
    fill: "#ff7112"
  }), /*#__PURE__*/react.createElement("path", {
    d: "M111.832 0a2.1 2.1 0 0 0-2.099 2.098 2.1 2.1 0 0 0 2.099 2.098 2.1 2.1 0 0 0 2.098-2.098A2.1 2.1 0 0 0 111.832 0z",
    fill: "#fccc12"
  }), /*#__PURE__*/react.createElement("path", {
    d: "M7.292 12.353c-3.194 0-5.658 2.505-5.658 5.679L1.641 35h1.828V18.074c0-2.327 1.748-4.018 3.848-4.018s3.848 1.691 3.848 4.018c0 1.471-.718 3.079-2.545 3.795l-5.151 2.019-.001 1.707.09.096 5.471-2.274c1.644-.717 2.196-1.255 2.201-1.261a5.687 5.687 0 0 0 1.769-4.124 5.678 5.678 0 0 0-5.707-5.679z",
    fill: "url(#pwob_b)"
  }), /*#__PURE__*/react.createElement("use", {
    xlinkHref: "#pwob_c",
    fill: "url(#pwob_d)"
  }), /*#__PURE__*/react.createElement("use", {
    xlinkHref: "#pwob_c",
    fill: "url(#pwob_e)"
  }), /*#__PURE__*/react.createElement("path", {
    d: "M19.377 19.612h10.669l-.016-.033-1.683-1.631-9.296.015a4.4 4.4 0 0 0 .326 1.649z",
    fill: "url(#pwob_f)"
  }), /*#__PURE__*/react.createElement("path", {
    d: "m19.094 18.023 9.218.005-1.76-1.584h-7.147a4.2 4.2 0 0 0-.311 1.58z",
    fill: "#fff"
  }), /*#__PURE__*/react.createElement("path", {
    d: "M23.045 22.046a3.75 3.75 0 0 1-2.46-.889v.001l-.021-.019a3.87 3.87 0 0 1-1.073-1.526 4.248 4.248 0 0 1-.3-1.583 4.21 4.21 0 0 1 .305-1.586l.056-.126.024-.055a3.92 3.92 0 0 1 .934-1.284l.076-.069v.003a3.746 3.746 0 0 1 2.46-.903c1.658 0 2.903.997 3.426 2.433l1.866 1.609c.047-1.584-.525-3.067-1.552-4.12-.986-1.011-2.356-1.567-3.814-1.567-3.11 0-5.675 2.552-5.675 5.663s2.554 5.667 5.665 5.667c1.82 0 3.517-.885 4.57-2.326l-1.302-.903c-.334.552-1.4 1.582-3.183 1.582z",
    fill: "url(#pwob_g)"
  }), /*#__PURE__*/react.createElement("path", {
    d: "M22.97 23.685c-3.042 0-5.655-2.532-5.655-5.658s2.626-5.664 5.655-5.658c1.413.002 2.814.554 3.806 1.571 1.037 1.063 1.572 2.515 1.534 4.088l1.735 1.585a7.83 7.83 0 0 0 .167-1.585c0-4.035-3.133-7.317-7.167-7.317a7.33 7.33 0 0 0-7.317 7.317 7.33 7.33 0 0 0 7.317 7.317c2.4 0 4.673-1.162 5.968-2.953l-1.483-1.025c-1.079 1.443-2.752 2.318-4.559 2.318z",
    fill: "url(#pwob_h)"
  }), /*#__PURE__*/react.createElement("path", {
    d: "M42.621 12.458v-1.321h1.692v6.077l-.014-.127c-.169-1.526-.892-3.429-1.678-4.629zm.705 9.918c-.22.465-.461.849-.705 1.221v1.321h1.692V18.76l-.028.393c-.109.982-.441 2.133-.959 3.224z",
    fill: "#eeefef"
  }), /*#__PURE__*/react.createElement("use", {
    xlinkHref: "#pwob_i",
    fill: "url(#pwob_j)"
  }), /*#__PURE__*/react.createElement("use", {
    xlinkHref: "#pwob_i",
    fill: "url(#pwob_k)",
    fillOpacity: ".2"
  }), /*#__PURE__*/react.createElement("path", {
    d: "M38.791 12.32c-3.076 0-5.639 2.569-5.639 5.72s2.393 5.74 5.639 5.74c3.076 0 5.58-2.578 5.58-5.73s-2.502-5.731-5.58-5.731zm.029 9.625c-2.196 0-3.865-1.746-3.865-3.963s1.709-3.966 3.865-3.963c2.177.002 3.787 1.81 3.8 3.993.001 2.215-1.605 3.932-3.8 3.932z",
    fill: "url(#pwob_l)"
  }), /*#__PURE__*/react.createElement("path", {
    d: "M46.091 11.137h-1.779v13.781h1.779V11.137z",
    fill: "url(#pwob_m)"
  }), /*#__PURE__*/react.createElement("use", {
    xlinkHref: "#pwob_n",
    fill: "url(#pwob_o)"
  }), /*#__PURE__*/react.createElement("use", {
    xlinkHref: "#pwob_n",
    fill: "url(#pwob_p)"
  }), /*#__PURE__*/react.createElement("use", {
    xlinkHref: "#pwob_q",
    fill: "url(#pwob_r)"
  }), /*#__PURE__*/react.createElement("path", {
    d: "M68.524 10.704a7.33 7.33 0 0 0-7.317 7.317 7.33 7.33 0 0 0 7.317 7.317 7.33 7.33 0 0 0 7.317-7.317 7.33 7.33 0 0 0-7.317-7.317zm0 12.861c-3.005 0-5.436-2.468-5.436-5.518s2.43-5.517 5.436-5.517 5.437 2.467 5.437 5.517-2.432 5.518-5.437 5.518z",
    fill: "url(#pwob_s)"
  }), /*#__PURE__*/react.createElement("path", {
    d: "M68.524 12.24c-3.147 0-5.72 2.539-5.72 5.808 0 3.31 2.574 5.809 5.72 5.809 3.284 0 5.723-2.613 5.723-5.809 0-3.256-2.576-5.808-5.723-5.808zm0 9.801c-2.22 0-3.848-1.771-3.848-4.018s1.667-4.018 3.848-4.018c2.22 0 3.848 1.771 3.848 4.018s-1.628 4.018-3.848 4.018z",
    fill: "url(#pwob_t)"
  }), /*#__PURE__*/react.createElement("use", {
    xlinkHref: "#pwob_n",
    x: "29.626",
    fill: "url(#pwob_u)"
  }), /*#__PURE__*/react.createElement("use", {
    xlinkHref: "#pwob_q",
    x: "29.626",
    fill: "url(#pwob_r)"
  }), /*#__PURE__*/react.createElement("path", {
    d: "M95.251 3.631h-1.802v21.286h1.802V3.631z",
    fill: "#fff"
  }), /*#__PURE__*/react.createElement("path", {
    d: "m98.367 17.731-.031-.039-1.187 1.248.027.039-.003.003 4.095 5.935h2.031l-4.932-7.186z",
    fill: "url(#pwob_v)"
  }), /*#__PURE__*/react.createElement("path", {
    d: "M103.248 24.918h2.221l-5.339-7.387-1.572-.009h-.025l-.203.218.009.015 4.909 7.164zm-9.738-4.39.014.005 8.802-9.396h-2.209l-4.864 5.253-1.742 4.106v.033z",
    fill: "#fff"
  }), /*#__PURE__*/react.createElement("path", {
    d: "M104.601 11.137h-2.339l-8.752 9.377v.017l1.742.472 1.859-1.95 1.458-1.532 6.032-6.384z",
    fill: "url(#pwob_w)"
  }), /*#__PURE__*/react.createElement("path", {
    d: "M93.51 3.631h-1.728v21.286h1.728V3.631z",
    fill: "url(#pwob_x)"
  }), /*#__PURE__*/react.createElement("defs", null, /*#__PURE__*/react.createElement("linearGradient", {
    id: "pwob_b",
    x1: ".273",
    y1: "23.002",
    x2: "9.021",
    y2: "15.036",
    xlinkHref: "#pwob_y"
  }, /*#__PURE__*/react.createElement("stop", {
    stopColor: "#fff"
  }), /*#__PURE__*/react.createElement("stop", {
    offset: ".498",
    stopColor: "#fff"
  }), /*#__PURE__*/react.createElement("stop", {
    offset: "1",
    stopColor: "#d7d9d9"
  })), /*#__PURE__*/react.createElement("linearGradient", {
    id: "pwob_d",
    x1: "0",
    y1: "19.575",
    x2: "3.858",
    y2: "27.689",
    xlinkHref: "#pwob_y"
  }, /*#__PURE__*/react.createElement("stop", {
    stopColor: "#fff"
  }), /*#__PURE__*/react.createElement("stop", {
    offset: "1",
    stopColor: "#c7c7c7"
  })), /*#__PURE__*/react.createElement("linearGradient", {
    id: "pwob_e",
    x1: "1.192",
    y1: "24.398",
    x2: "3.631",
    y2: "23.377",
    xlinkHref: "#pwob_y"
  }, /*#__PURE__*/react.createElement("stop", {
    stopColor: "#f3f4f4"
  }), /*#__PURE__*/react.createElement("stop", {
    offset: ".966",
    stopColor: "#f1f2f2",
    stopOpacity: "0"
  })), /*#__PURE__*/react.createElement("linearGradient", {
    id: "pwob_f",
    x1: "29.401",
    y1: "19.108",
    x2: "19.926",
    y2: "18.767",
    xlinkHref: "#pwob_y"
  }, /*#__PURE__*/react.createElement("stop", {
    stopColor: "#d1d3d4"
  }), /*#__PURE__*/react.createElement("stop", {
    offset: "1",
    stopColor: "#fff"
  })), /*#__PURE__*/react.createElement("linearGradient", {
    id: "pwob_g",
    x1: "22.809",
    y1: "24.228",
    x2: "23.66",
    y2: "12.369",
    xlinkHref: "#pwob_y"
  }, /*#__PURE__*/react.createElement("stop", {
    offset: ".078",
    stopColor: "#fff"
  }), /*#__PURE__*/react.createElement("stop", {
    offset: ".495",
    stopColor: "#fff"
  }), /*#__PURE__*/react.createElement("stop", {
    offset: "1",
    stopColor: "#d1d3d4"
  })), /*#__PURE__*/react.createElement("linearGradient", {
    id: "pwob_h",
    x1: "17.872",
    y1: "25.306",
    x2: "26.837",
    y2: "8.681",
    xlinkHref: "#pwob_y"
  }, /*#__PURE__*/react.createElement("stop", {
    stopColor: "#d1d3d4"
  }), /*#__PURE__*/react.createElement("stop", {
    offset: ".181",
    stopColor: "#d1d3d4"
  }), /*#__PURE__*/react.createElement("stop", {
    offset: ".587",
    stopColor: "#fff"
  })), /*#__PURE__*/react.createElement("linearGradient", {
    id: "pwob_j",
    x1: "35.859",
    y1: "25.93",
    x2: "41.581",
    y2: "10.787",
    xlinkHref: "#pwob_y"
  }, /*#__PURE__*/react.createElement("stop", {
    offset: ".103",
    stopColor: "#d1d3d4"
  }), /*#__PURE__*/react.createElement("stop", {
    offset: ".714",
    stopColor: "#fff"
  })), /*#__PURE__*/react.createElement("linearGradient", {
    id: "pwob_k",
    x1: "45.221",
    y1: "15.887",
    x2: "40.171",
    y2: "18.497",
    xlinkHref: "#pwob_y"
  }, /*#__PURE__*/react.createElement("stop", {
    stopOpacity: ".81"
  }), /*#__PURE__*/react.createElement("stop", {
    offset: "1",
    stopOpacity: "0"
  })), /*#__PURE__*/react.createElement("linearGradient", {
    id: "pwob_l",
    x1: "36.994",
    y1: "24.568",
    x2: "39.679",
    y2: "9.592",
    xlinkHref: "#pwob_y"
  }, /*#__PURE__*/react.createElement("stop", {
    offset: ".058",
    stopColor: "#fff"
  }), /*#__PURE__*/react.createElement("stop", {
    offset: ".54",
    stopColor: "#f5f6f6"
  }), /*#__PURE__*/react.createElement("stop", {
    offset: ".759",
    stopColor: "#d1d3d4"
  }), /*#__PURE__*/react.createElement("stop", {
    offset: ".894",
    stopColor: "#eaeaea"
  })), /*#__PURE__*/react.createElement("linearGradient", {
    id: "pwob_m",
    x1: "46.091",
    y1: "17.122",
    x2: "44.275",
    y2: "17.122",
    xlinkHref: "#pwob_y"
  }, /*#__PURE__*/react.createElement("stop", {
    stopColor: "#f6f7f7"
  }), /*#__PURE__*/react.createElement("stop", {
    offset: "1",
    stopColor: "#fff"
  })), /*#__PURE__*/react.createElement("linearGradient", {
    id: "pwob_o",
    x1: "62.072",
    y1: "22.298",
    x2: "59.008",
    y2: "14.298",
    xlinkHref: "#pwob_y"
  }, /*#__PURE__*/react.createElement("stop", {
    stopColor: "#fff"
  }), /*#__PURE__*/react.createElement("stop", {
    offset: ".294",
    stopColor: "#fff"
  }), /*#__PURE__*/react.createElement("stop", {
    offset: ".659",
    stopColor: "#eee"
  }), /*#__PURE__*/react.createElement("stop", {
    offset: ".907",
    stopColor: "#d1d3d4"
  })), /*#__PURE__*/react.createElement("linearGradient", {
    id: "pwob_p",
    x1: "49.873",
    y1: "18.043",
    x2: "56.455",
    y2: "19.632",
    xlinkHref: "#pwob_y"
  }, /*#__PURE__*/react.createElement("stop", {
    stopColor: "#fff",
    stopOpacity: ".59"
  }), /*#__PURE__*/react.createElement("stop", {
    offset: "1",
    stopColor: "#fff",
    stopOpacity: "0"
  })), /*#__PURE__*/react.createElement("linearGradient", {
    id: "pwob_r",
    x1: "54.639",
    y1: "26.213",
    x2: "53.593",
    y2: "8.694",
    xlinkHref: "#pwob_y"
  }, /*#__PURE__*/react.createElement("stop", {
    stopColor: "#d1d3d4"
  }), /*#__PURE__*/react.createElement("stop", {
    offset: ".181",
    stopColor: "#d1d3d4"
  }), /*#__PURE__*/react.createElement("stop", {
    offset: ".329",
    stopColor: "#e9eaea"
  }), /*#__PURE__*/react.createElement("stop", {
    offset: ".642",
    stopColor: "#fff"
  })), /*#__PURE__*/react.createElement("linearGradient", {
    id: "pwob_s",
    x1: "66.101",
    y1: "27.121",
    x2: "73.626",
    y2: "11.453",
    xlinkHref: "#pwob_y"
  }, /*#__PURE__*/react.createElement("stop", {
    offset: ".054",
    stopColor: "#d1d3d4"
  }), /*#__PURE__*/react.createElement("stop", {
    offset: ".662",
    stopColor: "#fcfcfc"
  }), /*#__PURE__*/react.createElement("stop", {
    offset: ".936",
    stopColor: "#fff"
  })), /*#__PURE__*/react.createElement("linearGradient", {
    id: "pwob_t",
    x1: "66.499",
    y1: "24.941",
    x2: "70.281",
    y2: "12.697",
    xlinkHref: "#pwob_y"
  }, /*#__PURE__*/react.createElement("stop", {
    offset: ".054",
    stopColor: "#fff"
  }), /*#__PURE__*/react.createElement("stop", {
    offset: ".206",
    stopColor: "#fff"
  }), /*#__PURE__*/react.createElement("stop", {
    offset: ".907",
    stopColor: "#d3d5d6"
  })), /*#__PURE__*/react.createElement("linearGradient", {
    id: "pwob_u",
    x1: "56.852",
    y1: "26.043",
    x2: "61.051",
    y2: "12.256",
    xlinkHref: "#pwob_y"
  }, /*#__PURE__*/react.createElement("stop", {
    stopColor: "#fff"
  }), /*#__PURE__*/react.createElement("stop", {
    offset: ".294",
    stopColor: "#fff"
  }), /*#__PURE__*/react.createElement("stop", {
    offset: ".659",
    stopColor: "#eee"
  }), /*#__PURE__*/react.createElement("stop", {
    offset: ".907",
    stopColor: "#d1d3d4"
  })), /*#__PURE__*/react.createElement("linearGradient", {
    id: "pwob_v",
    x1: "98.272",
    y1: "18.303",
    x2: "100.057",
    y2: "24.81",
    xlinkHref: "#pwob_y"
  }, /*#__PURE__*/react.createElement("stop", {
    stopColor: "#fff"
  }), /*#__PURE__*/react.createElement("stop", {
    offset: ".392",
    stopColor: "#f1f2f2"
  }), /*#__PURE__*/react.createElement("stop", {
    offset: ".73",
    stopColor: "#e6e7e7"
  }), /*#__PURE__*/react.createElement("stop", {
    offset: "1",
    stopColor: "#d3d5d6"
  })), /*#__PURE__*/react.createElement("linearGradient", {
    id: "pwob_w",
    x1: "103.039",
    y1: "11.097",
    x2: "93.96",
    y2: "20.629",
    xlinkHref: "#pwob_y"
  }, /*#__PURE__*/react.createElement("stop", {
    stopColor: "#eeefef"
  }), /*#__PURE__*/react.createElement("stop", {
    offset: ".392",
    stopColor: "#f1f2f2"
  }), /*#__PURE__*/react.createElement("stop", {
    offset: ".73",
    stopColor: "#e8e9ea"
  }), /*#__PURE__*/react.createElement("stop", {
    offset: "1",
    stopColor: "#e6e7e8"
  })), /*#__PURE__*/react.createElement("linearGradient", {
    id: "pwob_x",
    x1: "92.598",
    y1: "4.061",
    x2: "92.598",
    y2: "24.601",
    xlinkHref: "#pwob_y"
  }, /*#__PURE__*/react.createElement("stop", {
    stopColor: "#f1f2f2"
  }), /*#__PURE__*/react.createElement("stop", {
    offset: ".392",
    stopColor: "#f1f2f2"
  }), /*#__PURE__*/react.createElement("stop", {
    offset: ".73",
    stopColor: "#e6e7e7"
  }), /*#__PURE__*/react.createElement("stop", {
    offset: "1",
    stopColor: "#d3d5d6"
  })), /*#__PURE__*/react.createElement("linearGradient", {
    id: "pwob_y",
    gradientUnits: "userSpaceOnUse"
  }), /*#__PURE__*/react.createElement("path", {
    id: "pwob_a",
    d: "M111.832 22.984a2.1 2.1 0 0 0-2.099 2.098 2.1 2.1 0 0 0 2.099 2.098 2.1 2.1 0 0 0 2.098-2.098 2.1 2.1 0 0 0-2.098-2.098z"
  }), /*#__PURE__*/react.createElement("path", {
    id: "pwob_c",
    d: "M7.317 10.757A7.33 7.33 0 0 0 0 18.074V35h1.659V18.034c0-3.126 2.532-5.655 5.658-5.655s5.659 2.527 5.659 5.655a5.6 5.6 0 0 1-1.766 4.1c-.005.005-.544.538-2.194 1.258l-5.464 2.292 1.184 1.259 5.096-1.996c2.914-1.136 4.802-3.744 4.802-6.873a7.33 7.33 0 0 0-7.318-7.317z"
  }), /*#__PURE__*/react.createElement("path", {
    id: "pwob_i",
    d: "M44.313 18.48v-.429l-.014-.499-.049.287.02.784c-.284 2.858-2.747 5.085-5.527 5.085-3.08 0-5.571-2.531-5.571-5.657 0-3.056 2.491-5.657 5.571-5.657 2.836 0 5.244 2.226 5.527 5.085l.042.572v-.808c-.014-1.336-.698-3.317-1.654-4.727l-.038-.058c-1.177-1.223-2.733-1.748-4.373-1.748-3.395 0-6.852 3.082-6.852 7.317s3.456 7.317 6.852 7.317c1.632 0 3.178-.52 4.353-1.727.835-1.14 1.76-3.426 1.712-5.137z"
  }), /*#__PURE__*/react.createElement("path", {
    id: "pwob_n",
    d: "M54.746 14.004a3.74 3.74 0 0 1 3.378 2.044l1.384-1.062c-1.02-1.677-2.805-2.718-4.75-2.718-3.085 0-5.636 2.611-5.636 5.791s2.551 5.815 5.636 5.815c1.96 0 3.771-1.08 4.787-2.786l-1.42-1.089a3.745 3.745 0 0 1-3.378 2.044c-2.22 0-3.848-1.771-3.848-4.018s1.667-4.019 3.847-4.019z"
  }), /*#__PURE__*/react.createElement("path", {
    id: "pwob_q",
    d: "M54.757 23.839c-3.03 0-5.611-2.586-5.611-5.782s2.59-5.778 5.611-5.778c1.93 0 3.724 1.021 4.75 2.705l1.327-1.017a7.316 7.316 0 0 0-6.089-3.264 7.33 7.33 0 0 0-7.317 7.317 7.33 7.33 0 0 0 7.317 7.317 7.316 7.316 0 0 0 6.089-3.264l-1.291-.989c-1.02 1.713-2.887 2.754-4.785 2.754z"
  })));
};

;// CONCATENATED MODULE: ./src/pages/Home/Body/Body.scss
// Exports
var body = `Body___body___SlQS9`;
var sectionCta = `Body___section-cta___MrnjK`;
var sectionIntro = `Body___section-intro___L5n5I`;
var sectionProducts = `Body___section-products___jBNbq`;
var sectionClients = `Body___section-clients___JDD5X`;
var sectionAbout = `Body___section-about___QHEw6`;

;// CONCATENATED MODULE: ./src/pages/Home/Body/Body.tsx





var SectionHero = function SectionHero(_ref) {
  var resourceStrings = _ref.resourceStrings;
  return /*#__PURE__*/react.createElement("section", {
    className: sectionCta
  }, /*#__PURE__*/react.createElement("div", null, /*#__PURE__*/react.createElement("div", null, /*#__PURE__*/react.createElement("div", {
    className: Body_namespaceObject.sectionCtaBackground
  }), /*#__PURE__*/react.createElement("img", {
    className: Body_namespaceObject.sectionCtaBackgroundImg,
    src: "/assets/screen.jpg",
    alt: "screen"
  })), /*#__PURE__*/react.createElement("div", {
    className: Body_namespaceObject.sectionCtaContent
  }, /*#__PURE__*/react.createElement("h2", {
    className: Body_namespaceObject.sectionCtaContentTitle
  }, resourceStrings.title), /*#__PURE__*/react.createElement("p", {
    className: Body_namespaceObject.sectionCtaContentDescription
  }, resourceStrings.description), /*#__PURE__*/react.createElement("div", {
    className: Body_namespaceObject.sectionCtaContentLinkContainer
  }, /*#__PURE__*/react.createElement("a", {
    href: "#about",
    className: Body_namespaceObject.sectionCtaContentLink
  }, resourceStrings.cta)))));
};
var SectionIntro = function SectionIntro(_ref2) {
  var resourceStrings = _ref2.resourceStrings;
  return /*#__PURE__*/react.createElement("section", {
    className: sectionIntro
  }, /*#__PURE__*/react.createElement("div", {
    className: Body_namespaceObject.sectionIntroContainer
  }, /*#__PURE__*/react.createElement("p", {
    className: Body_namespaceObject.sectionIntroContent
  }, resourceStrings.content)));
};
var SectionProducts = function SectionProducts(_ref3) {
  var resourceStrings = _ref3.resourceStrings;
  return /*#__PURE__*/react.createElement("section", {
    className: sectionProducts
  }, /*#__PURE__*/react.createElement("div", {
    className: Body_namespaceObject.sectionProductsContainer
  }, /*#__PURE__*/react.createElement(Card, {
    img: {
      src: "/assets/custom-software.jpg",
      alt: resourceStrings.solutions.imgAlt
    },
    title: resourceStrings.solutions.title,
    description: resourceStrings.solutions.description
  }), /*#__PURE__*/react.createElement(Card, {
    img: {
      src: "/assets/agile-methodology.jpg",
      alt: resourceStrings.methodology.imgAlt
    },
    title: resourceStrings.methodology.title,
    description: resourceStrings.methodology.description
  }), /*#__PURE__*/react.createElement(Card, {
    img: {
      src: "/assets/tech-support.jpg",
      alt: resourceStrings.support.imgAlt
    },
    title: resourceStrings.support.title,
    description: resourceStrings.support.description
  })));
};
var SectionClients = function SectionClients(_ref4) {
  var resourceStrings = _ref4.resourceStrings;
  return /*#__PURE__*/react.createElement("section", {
    className: sectionClients
  }, /*#__PURE__*/react.createElement("div", {
    className: Body_namespaceObject.sectionClientsContainer
  }, /*#__PURE__*/react.createElement("h2", {
    className: Body_namespaceObject.sectionClientsTitle
  }, resourceStrings.title), /*#__PURE__*/react.createElement("div", {
    className: Body_namespaceObject.sectionClientsIcons
  }, /*#__PURE__*/react.createElement(Peacock, {
    className: Body_namespaceObject.sectionClientsIconsGeneric
  }), /*#__PURE__*/react.createElement(Dazn, {
    className: Body_namespaceObject.sectionClientsIconsGeneric
  }), /*#__PURE__*/react.createElement("div", {
    className: Body_namespaceObject.sectionClientsIconsSky
  }))));
};
var SectionAbout = function SectionAbout(_ref5) {
  var resourceStrings = _ref5.resourceStrings;
  return /*#__PURE__*/react.createElement("section", {
    className: sectionAbout
  }, /*#__PURE__*/react.createElement("div", {
    className: Body_namespaceObject.sectionAboutContainer
  }, /*#__PURE__*/react.createElement("div", null, /*#__PURE__*/react.createElement("h2", {
    className: Body_namespaceObject.sectionAboutTitle
  }, /*#__PURE__*/react.createElement("a", {
    name: "about"
  }, resourceStrings.title)), /*#__PURE__*/react.createElement("p", {
    className: Body_namespaceObject.sectionAboutDescription
  }, resourceStrings.description)), /*#__PURE__*/react.createElement("div", {
    className: Body_namespaceObject.sectionAboutBackground
  }, /*#__PURE__*/react.createElement("img", {
    className: Body_namespaceObject.sectionAboutBackgroundImg,
    src: "/assets/setup.jpg",
    alt: resourceStrings.imgAlt
  }))));
};
var Body = function Body(_ref6) {
  var resourceStrings = _ref6.resourceStrings;
  return /*#__PURE__*/react.createElement("div", {
    className: body
  }, /*#__PURE__*/react.createElement(SectionHero, {
    resourceStrings: resourceStrings.section.hero
  }), /*#__PURE__*/react.createElement(SectionIntro, {
    resourceStrings: resourceStrings.section.intro
  }), /*#__PURE__*/react.createElement(SectionProducts, {
    resourceStrings: resourceStrings.section.products
  }), /*#__PURE__*/react.createElement(SectionClients, {
    resourceStrings: resourceStrings.section.clients
  }), /*#__PURE__*/react.createElement(SectionAbout, {
    resourceStrings: resourceStrings.section.about
  }));
};

;// CONCATENATED MODULE: ./src/icons/atlantic.tsx
function atlantic_extends() { atlantic_extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return atlantic_extends.apply(this, arguments); }

var Atlantic = function Atlantic(props) {
  return /*#__PURE__*/react.createElement("svg", atlantic_extends({
    width: "562.25",
    height: "127.25232718031042",
    viewBox: "0 0 369.66666666666663 83.66552888274151"
  }, props), /*#__PURE__*/react.createElement("g", {
    transform: "matrix(1.0462439640538823,0,0,1.0462439640538823,-10.6716882337944,-10.46238675841097)",
    fill: "#0092ca"
  }, /*#__PURE__*/react.createElement("path", {
    d: "M20,41.37a37.51,37.51,0,0,1,16.79.46c6.3,1.4,13.16,4.21,20,6.66S70.6,53,76.92,52.91a26.65,26.65,0,0,0,12.93-3.25,40.9,40.9,0,0,0-.5-6,25.53,25.53,0,0,1-13.69.43c-6-1.26-12.41-4.38-18.8-7.46s-12.77-6.1-18.77-7.21a24.93,24.93,0,0,0-16.41,2A37.92,37.92,0,0,0,11.2,39.66a40,40,0,0,0-1,5.4A43.17,43.17,0,0,1,20,41.37Z",
    style: {
      "fillRule": "evenodd"
    }
  }), /*#__PURE__*/react.createElement("path", {
    d: "M78.11,61.13c-6.69.77-14-.68-21.25-2.49S42.29,54.7,35.57,54a43.67,43.67,0,0,0-17.88,1.51c-2.69.8-5.06,1.79-7,2.52A40.24,40.24,0,0,0,13,65.63c.94,0,1.94,0,3-.07a96.05,96.05,0,0,1,18.26.91c7,.94,14.8,2.85,22.57,4S72.39,72,79.4,69.92A32.83,32.83,0,0,0,86,67.22a39.48,39.48,0,0,0,3.12-9.4A29.57,29.57,0,0,1,78.11,61.13Z",
    style: {
      "fillRule": "evenodd"
    }
  }), /*#__PURE__*/react.createElement("path", {
    d: "M49.85,10a39.84,39.84,0,0,0-22.34,6.81,32.75,32.75,0,0,1,11.57,2.92c5.6,2.36,11.69,6.06,17.78,9.53S69,35.79,74.64,37a23.37,23.37,0,0,0,12.9-.44A40,40,0,0,0,49.85,10Z",
    style: {
      "fillRule": "evenodd"
    }
  }), /*#__PURE__*/react.createElement("path", {
    d: "M76.53,79.8c-6.27,1.53-13,1.55-19.67,1-8.2-.65-16.4-2-23.83-2.3a98.91,98.91,0,0,0-11.18,0A40,40,0,0,0,76.53,79.8Z",
    style: {
      "fillRule": "evenodd"
    }
  })), /*#__PURE__*/react.createElement("g", {
    transform: "matrix(3.715055324625889,0,0,3.715055324625889,102.99999822852358,-4.163555174617265)",
    fill: "#393e46"
  }, /*#__PURE__*/react.createElement("path", {
    d: "M7.52 5 l6.16 15 l-2.4 0 l-1.5 -3.92 l-5.9 0 l-1.48 3.92 l-2.4 0 l6.16 -15 l1.36 0 z M4.58 14.24 l4.5 0 l-2.24 -5.92 z M18.880000000000003 18.36 c0.64 0.26 1.14 0.08 1.44 -0.06 l0 1.6 c-0.26 0.16 -0.64 0.3 -1.18 0.3 c-1.18 0 -2.22 -0.38 -2.86 -1.42 c-0.6 -1 -0.6 -1.54 -0.6 -3.1 l0 -3.88 l-1.2 0 l0 -1.68 l1.2 0 l0 -3.12 l2.06 0 l0 3.12 l2.58 0 l0 1.68 l-2.58 0 l0 3.88 c0 1.64 0.16 2.24 1.14 2.68 z M25.000000000000004 4.619999999999999 l0 15.38 l-2.08 0 l0 -15.38 l2.08 0 z M32.220000000000006 9.92 c2.84 0 3.98 1.72 3.98 3.18 l0 6.9 l-2.06 0 l0 -1.08 c-0.72 0.98 -2 1.26 -2.8 1.26 c-2.26 0 -3.74 -1.32 -3.74 -3.08 c0 -2.46 1.84 -3.34 3.74 -3.34 l2.8 0 l0 -0.66 c0 -0.62 -0.24 -1.48 -1.92 -1.48 c-0.94 0 -1.8 0.5 -2.36 1.28 l-1.42 -1.28 c0.94 -1.04 2.28 -1.7 3.78 -1.7 z M34.14 16.92 l0 -1.48 l-2.52 0 c-1.22 0 -2.08 0.62 -1.94 1.74 c0.12 0.94 0.88 1.32 1.94 1.32 c1.9 0 2.52 -0.9 2.52 -1.58 z M47.82000000000001 14.3 l0 5.7 l-2.06 0 l0 -5.5 c0 -2 -0.62 -2.88 -2.32 -2.88 c-1.92 0 -2.7 1.34 -2.7 3.08 l0 5.3 l-2.06 0 l0 -9.88 l2.06 0 l0 1.6 c0.28 -0.88 1.52 -1.68 2.7 -1.76 c2.68 -0.2 4.38 1.1 4.38 4.34 z M54.36000000000001 18.36 c0.64 0.26 1.14 0.08 1.44 -0.06 l0 1.6 c-0.26 0.16 -0.64 0.3 -1.18 0.3 c-1.18 0 -2.22 -0.38 -2.86 -1.42 c-0.6 -1 -0.6 -1.54 -0.6 -3.1 l0 -3.88 l-1.2 0 l0 -1.68 l1.2 0 l0 -3.12 l2.06 0 l0 3.12 l2.58 0 l0 1.68 l-2.58 0 l0 3.88 c0 1.64 0.16 2.24 1.14 2.68 z M60.56000000000001 10.12 l0 9.88 l-2.06 0 l0 -9.88 l2.06 0 z M60.66000000000001 6.5 c0 0.64 -0.5 1.14 -1.14 1.14 c-0.62 0 -1.12 -0.5 -1.12 -1.14 c0 -0.62 0.5 -1.12 1.12 -1.12 c0.64 0 1.14 0.5 1.14 1.12 z M70.36 17.42 l1.42 1.28 c-0.94 1.04 -2.28 1.5 -3.78 1.5 c-2.84 0 -5.14 -2.18 -5.14 -5.12 s2.3 -5.14 5.14 -5.14 c1.5 0 2.84 0.46 3.78 1.5 l-1.42 1.28 c-0.58 -0.78 -1.42 -1.08 -2.36 -1.08 c-1.7 0 -3.08 1.42 -3.08 3.44 c0 2 1.38 3.44 3.08 3.44 c0.94 0 1.78 -0.3 2.36 -1.1 z"
  })));
};

;// CONCATENATED MODULE: ./src/components/Dropdown/Dropdown.scss
// Exports
var container = `Dropdown___container___VZhQQ`;
var Dropdown_button = `Dropdown___button___Oje7s`;
var menu = `Dropdown___menu___p8AhS`;
var Dropdown_option = `Dropdown___option___LitYA`;

;// CONCATENATED MODULE: ./src/components/Dropdown/Dropdown.tsx
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function _iterableToArrayLimit(r, l) { var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (null != t) { var e, n, i, u, a = [], f = !0, o = !1; try { if (i = (t = t.call(r)).next, 0 === l) { if (Object(t) !== t) return; f = !1; } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0); } catch (r) { o = !0, n = r; } finally { try { if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return; } finally { if (o) throw n; } } return a; } }
function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }


var Dropdown = function Dropdown(props) {
  var _React$useState = react.useState(props["default"]),
    _React$useState2 = _slicedToArray(_React$useState, 2),
    selected = _React$useState2[0],
    setSelected = _React$useState2[1];
  var _React$useState3 = react.useState(false),
    _React$useState4 = _slicedToArray(_React$useState3, 2),
    isOpen = _React$useState4[0],
    setOpen = _React$useState4[1];
  var menuRef = react.useRef(null);
  var close = function close(event) {
    var concernedElement = document.querySelector(".".concat(container));
    var hasClickedInside = concernedElement && concernedElement.contains(event.target);
    if (!hasClickedInside) {
      setOpen(false);
    }
  };
  var _onClick = function onClick() {
    setOpen(function (prev) {
      return !prev;
    });
  };
  react.useEffect(function () {
    document.addEventListener("click", close);
    return function () {
      document.removeEventListener("click", close);
    };
  }, [isOpen]);
  return /*#__PURE__*/react.createElement("div", {
    className: container
  }, /*#__PURE__*/react.createElement("button", {
    onClick: _onClick,
    className: Dropdown_button
  }, /*#__PURE__*/react.createElement("span", {
    className: Dropdown_namespaceObject.buttonImg
  }, selected.img), /*#__PURE__*/react.createElement("span", {
    className: Dropdown_namespaceObject.buttonValue
  }, selected.value)), isOpen ? /*#__PURE__*/react.createElement("ul", {
    className: menu,
    ref: menuRef
  }, props.options.map(function (option) {
    return /*#__PURE__*/react.createElement("li", {
      key: option.key,
      onClick: function onClick() {
        setSelected(option);
        props.onSelect(option);
        _onClick();
      },
      className: Dropdown_option
    }, /*#__PURE__*/react.createElement("span", {
      className: Dropdown_namespaceObject.optionImg
    }, option.img), /*#__PURE__*/react.createElement("span", {
      className: Dropdown_namespaceObject.optionValue
    }, option.value));
  })) : null);
};

;// CONCATENATED MODULE: ./src/icons/greatBritain.tsx

var IconGreatBritain = function IconGreatBritain() {
  return /*#__PURE__*/react.createElement("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 512 512"
  }, /*#__PURE__*/react.createElement("mask", {
    id: "a"
  }, /*#__PURE__*/react.createElement("circle", {
    cx: "256",
    cy: "256",
    r: "256",
    fill: "#fff"
  })), /*#__PURE__*/react.createElement("g", {
    mask: "url(#a)"
  }, /*#__PURE__*/react.createElement("path", {
    fill: "#eee",
    d: "m0 0 8 22-8 23v23l32 54-32 54v32l32 48-32 48v32l32 54-32 54v68l22-8 23 8h23l54-32 54 32h32l48-32 48 32h32l54-32 54 32h68l-8-22 8-23v-23l-32-54 32-54v-32l-32-48 32-48v-32l-32-54 32-54V0l-22 8-23-8h-23l-54 32-54-32h-32l-48 32-48-32h-32l-54 32L68 0H0z"
  }), /*#__PURE__*/react.createElement("path", {
    fill: "#0052b4",
    d: "M336 0v108L444 0Zm176 68L404 176h108zM0 176h108L0 68ZM68 0l108 108V0Zm108 512V404L68 512ZM0 444l108-108H0Zm512-108H404l108 108Zm-68 176L336 404v108z"
  }), /*#__PURE__*/react.createElement("path", {
    fill: "#d80027",
    d: "M0 0v45l131 131h45L0 0zm208 0v208H0v96h208v208h96V304h208v-96H304V0h-96zm259 0L336 131v45L512 0h-45zM176 336 0 512h45l131-131v-45zm160 0 176 176v-45L381 336h-45z"
  })));
};

;// CONCATENATED MODULE: ./src/icons/portugal.tsx

var IconPortugal = function IconPortugal() {
  return /*#__PURE__*/react.createElement("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 512 512"
  }, /*#__PURE__*/react.createElement("mask", {
    id: "a"
  }, /*#__PURE__*/react.createElement("circle", {
    cx: "256",
    cy: "256",
    r: "256",
    fill: "#fff"
  })), /*#__PURE__*/react.createElement("g", {
    mask: "url(#a)"
  }, /*#__PURE__*/react.createElement("path", {
    fill: "#6da544",
    d: "M0 512h167l37.9-260.3L167 0H0z"
  }), /*#__PURE__*/react.createElement("path", {
    fill: "#d80027",
    d: "M512 0H167v512h345z"
  }), /*#__PURE__*/react.createElement("circle", {
    cx: "167",
    cy: "256",
    r: "89",
    fill: "#ffda44"
  }), /*#__PURE__*/react.createElement("path", {
    fill: "#d80027",
    d: "M116.9 211.5V267a50 50 0 1 0 100.1 0v-55.6H117z"
  }), /*#__PURE__*/react.createElement("path", {
    fill: "#eee",
    d: "M167 283.8c-9.2 0-16.7-7.5-16.7-16.7V245h33.4v22c0 9.2-7.5 16.7-16.7 16.7z"
  })));
};

;// CONCATENATED MODULE: ./src/icons/spain.tsx

var IconSpain = function IconSpain() {
  return /*#__PURE__*/react.createElement("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 512 512"
  }, /*#__PURE__*/react.createElement("mask", {
    id: "a"
  }, /*#__PURE__*/react.createElement("circle", {
    cx: "256",
    cy: "256",
    r: "256",
    fill: "#fff"
  })), /*#__PURE__*/react.createElement("g", {
    mask: "url(#a)"
  }, /*#__PURE__*/react.createElement("path", {
    fill: "#ffda44",
    d: "m0 128 256-32 256 32v256l-256 32L0 384Z"
  }), /*#__PURE__*/react.createElement("path", {
    fill: "#d80027",
    d: "M0 0h512v128H0zm0 384h512v128H0z"
  }), /*#__PURE__*/react.createElement("g", {
    fill: "#eee"
  }, /*#__PURE__*/react.createElement("path", {
    d: "M144 304h-16v-80h16zm128 0h16v-80h-16z"
  }), /*#__PURE__*/react.createElement("ellipse", {
    cx: "208",
    cy: "296",
    rx: "48",
    ry: "32"
  })), /*#__PURE__*/react.createElement("g", {
    fill: "#d80027"
  }, /*#__PURE__*/react.createElement("rect", {
    width: "16",
    height: "24",
    x: "128",
    y: "192",
    rx: "8"
  }), /*#__PURE__*/react.createElement("rect", {
    width: "16",
    height: "24",
    x: "272",
    y: "192",
    rx: "8"
  }), /*#__PURE__*/react.createElement("path", {
    d: "M208 272v24a24 24 0 0 0 24 24 24 24 0 0 0 24-24v-24h-24z"
  })), /*#__PURE__*/react.createElement("rect", {
    width: "32",
    height: "16",
    x: "120",
    y: "208",
    fill: "#ff9811",
    ry: "8"
  }), /*#__PURE__*/react.createElement("rect", {
    width: "32",
    height: "16",
    x: "264",
    y: "208",
    fill: "#ff9811",
    ry: "8"
  }), /*#__PURE__*/react.createElement("rect", {
    width: "32",
    height: "16",
    x: "120",
    y: "304",
    fill: "#ff9811",
    rx: "8"
  }), /*#__PURE__*/react.createElement("rect", {
    width: "32",
    height: "16",
    x: "264",
    y: "304",
    fill: "#ff9811",
    rx: "8"
  }), /*#__PURE__*/react.createElement("path", {
    fill: "#ff9811",
    d: "M160 272v24c0 8 4 14 9 19l5-6 5 10a21 21 0 0 0 10 0l5-10 5 6c6-5 9-11 9-19v-24h-9l-5 8-5-8h-10l-5 8-5-8z"
  }), /*#__PURE__*/react.createElement("path", {
    d: "M122 252h172m-172 24h28m116 0h28"
  }), /*#__PURE__*/react.createElement("path", {
    fill: "#d80027",
    d: "M122 248a4 4 0 0 0-4 4 4 4 0 0 0 4 4h172a4 4 0 0 0 4-4 4 4 0 0 0-4-4zm0 24a4 4 0 0 0-4 4 4 4 0 0 0 4 4h28a4 4 0 0 0 4-4 4 4 0 0 0-4-4zm144 0a4 4 0 0 0-4 4 4 4 0 0 0 4 4h28a4 4 0 0 0 4-4 4 4 0 0 0-4-4z"
  }), /*#__PURE__*/react.createElement("path", {
    fill: "#eee",
    d: "M196 168c-7 0-13 5-15 11l-5-1c-9 0-16 7-16 16s7 16 16 16c7 0 13-4 15-11a16 16 0 0 0 17-4 16 16 0 0 0 17 4 16 16 0 1 0 10-20 16 16 0 0 0-27-5c-3-4-7-6-12-6zm0 8c5 0 8 4 8 8 0 5-3 8-8 8-4 0-8-3-8-8 0-4 4-8 8-8zm24 0c5 0 8 4 8 8 0 5-3 8-8 8-4 0-8-3-8-8 0-4 4-8 8-8zm-44 10 4 1 4 8c0 4-4 7-8 7s-8-3-8-8c0-4 4-8 8-8zm64 0c5 0 8 4 8 8 0 5-3 8-8 8-4 0-8-3-8-7l4-8z"
  }), /*#__PURE__*/react.createElement("path", {
    fill: "none",
    d: "M220 284v12c0 7 5 12 12 12s12-5 12-12v-12z"
  }), /*#__PURE__*/react.createElement("path", {
    fill: "#ff9811",
    d: "M200 160h16v32h-16z"
  }), /*#__PURE__*/react.createElement("path", {
    fill: "#eee",
    d: "M208 224h48v48h-48z"
  }), /*#__PURE__*/react.createElement("path", {
    fill: "#d80027",
    d: "m248 208-8 8h-64l-8-8c0-13 18-24 40-24s40 11 40 24zm-88 16h48v48h-48z"
  }), /*#__PURE__*/react.createElement("rect", {
    width: "20",
    height: "32",
    x: "222",
    y: "232",
    fill: "#d80027",
    rx: "10",
    ry: "10"
  }), /*#__PURE__*/react.createElement("path", {
    fill: "#ff9811",
    d: "M168 232v8h8v16h-8v8h32v-8h-8v-16h8v-8zm8-16h64v8h-64z"
  }), /*#__PURE__*/react.createElement("g", {
    fill: "#ffda44"
  }, /*#__PURE__*/react.createElement("circle", {
    cx: "186",
    cy: "202",
    r: "6"
  }), /*#__PURE__*/react.createElement("circle", {
    cx: "208",
    cy: "202",
    r: "6"
  }), /*#__PURE__*/react.createElement("circle", {
    cx: "230",
    cy: "202",
    r: "6"
  })), /*#__PURE__*/react.createElement("path", {
    fill: "#d80027",
    d: "M169 272v43a24 24 0 0 0 10 4v-47h-10zm20 0v47a24 24 0 0 0 10-4v-43h-10z"
  }), /*#__PURE__*/react.createElement("g", {
    fill: "#338af3"
  }, /*#__PURE__*/react.createElement("circle", {
    cx: "208",
    cy: "272",
    r: "16"
  }), /*#__PURE__*/react.createElement("rect", {
    width: "32",
    height: "16",
    x: "264",
    y: "320",
    ry: "8"
  }), /*#__PURE__*/react.createElement("rect", {
    width: "32",
    height: "16",
    x: "120",
    y: "320",
    ry: "8"
  }))));
};

;// CONCATENATED MODULE: ./src/icons/russia.tsx

var IconRussia = function IconRussia() {
  return /*#__PURE__*/react.createElement("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 512 512"
  }, /*#__PURE__*/react.createElement("mask", {
    id: "a"
  }, /*#__PURE__*/react.createElement("circle", {
    cx: "256",
    cy: "256",
    r: "256",
    fill: "#fff"
  })), /*#__PURE__*/react.createElement("g", {
    mask: "url(#a)"
  }, /*#__PURE__*/react.createElement("path", {
    fill: "#0052b4",
    d: "M512 170v172l-256 32L0 342V170l256-32z"
  }), /*#__PURE__*/react.createElement("path", {
    fill: "#eee",
    d: "M512 0v170H0V0Z"
  }), /*#__PURE__*/react.createElement("path", {
    fill: "#d80027",
    d: "M512 342v170H0V342Z"
  })));
};

;// CONCATENATED MODULE: ./src/components/Header/Header.scss
// Exports
var header = `Header___header___eT9RT`;

;// CONCATENATED MODULE: ./src/icons/france.tsx

var IconFrance = function IconFrance() {
  return /*#__PURE__*/react.createElement("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 512 512"
  }, /*#__PURE__*/react.createElement("mask", {
    id: "a"
  }, /*#__PURE__*/react.createElement("circle", {
    cx: "256",
    cy: "256",
    r: "256",
    fill: "#fff"
  })), /*#__PURE__*/react.createElement("g", {
    mask: "url(#a)"
  }, /*#__PURE__*/react.createElement("path", {
    fill: "#eee",
    d: "M167 0h178l25.9 252.3L345 512H167l-29.8-253.4z"
  }), /*#__PURE__*/react.createElement("path", {
    fill: "#0052b4",
    d: "M0 0h167v512H0z"
  }), /*#__PURE__*/react.createElement("path", {
    fill: "#d80027",
    d: "M345 0h167v512H345z"
  })));
};

;// CONCATENATED MODULE: ./src/components/Header/Header.tsx
function Header_typeof(o) { "@babel/helpers - typeof"; return Header_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, Header_typeof(o); }
function Header_defineProperty(obj, key, value) { key = Header_toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function Header_toPropertyKey(t) { var i = Header_toPrimitive(t, "string"); return "symbol" == Header_typeof(i) ? i : String(i); }
function Header_toPrimitive(t, r) { if ("object" != Header_typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != Header_typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }











var countryImages = Header_defineProperty(Header_defineProperty(Header_defineProperty(Header_defineProperty(Header_defineProperty({}, ResourceStringLanguage.ENGLISH, /*#__PURE__*/react.createElement(IconGreatBritain, null)), ResourceStringLanguage.FRENCH, /*#__PURE__*/react.createElement(IconFrance, null)), ResourceStringLanguage.PORTUGUESE, /*#__PURE__*/react.createElement(IconPortugal, null)), ResourceStringLanguage.RUSSIAN, /*#__PURE__*/react.createElement(IconRussia, null)), ResourceStringLanguage.SPANISH, /*#__PURE__*/react.createElement(IconSpain, null));
var getOption = function getOption(key) {
  if (!key || key === "" || key === "undefined") {
    return {
      img: /*#__PURE__*/react.createElement(IconGreatBritain, null),
      key: "ENGLISH",
      value: ResourceStringLanguage.ENGLISH
    };
  }
  return {
    key: key,
    img: countryImages[Object(ResourceStringLanguage)[key]],
    value: Object(ResourceStringLanguage)[key]
  };
};
var Header = function Header() {
  var navigate = (0,dist.useNavigate)();
  var location = (0,dist.useLocation)();
  var langPath = location.pathname.split("/")[1];
  var currentLanguage = Object.keys(ResourceStringLanguage).find(function (key) {
    return ResourceStringLanguage[key] === langPath;
  }) || "ENGLISH";
  return /*#__PURE__*/react.createElement("header", {
    className: header
  }, /*#__PURE__*/react.createElement("div", {
    className: Header_namespaceObject.headerGrid
  }, /*#__PURE__*/react.createElement("div", {
    className: Header_namespaceObject.headerGridColumn
  }, /*#__PURE__*/react.createElement("a", {
    href: "/",
    "aria-label": "Atlantic Blue Solutions",
    className: Header_namespaceObject.headerLogo
  }, /*#__PURE__*/react.createElement(Atlantic, {
    className: Header_namespaceObject.headerLogoIcon
  }))), /*#__PURE__*/react.createElement("div", null, /*#__PURE__*/react.createElement(Dropdown, {
    onSelect: function onSelect(selected) {
      navigate("/".concat(Object(ResourceStringLanguage)[selected.key]));
    },
    "default": getOption(currentLanguage),
    options: Object.keys(ResourceStringLanguage).map(getOption)
  })), /*#__PURE__*/react.createElement("div", null)));
};

;// CONCATENATED MODULE: ./src/components/Footer/Footer.scss
// Exports
var footer = `Footer___footer___WQbgP`;

;// CONCATENATED MODULE: ./src/components/Footer/Footer.tsx



var Footer = function Footer() {
  return /*#__PURE__*/react.createElement("div", {
    className: footer
  }, /*#__PURE__*/react.createElement("div", {
    className: Footer_namespaceObject.footerGrid
  }, /*#__PURE__*/react.createElement("div", {
    className: Footer_namespaceObject.footerGridColumn
  }, /*#__PURE__*/react.createElement("a", {
    href: "/",
    "aria-label": "Atlantic Blue Solutions",
    className: Footer_namespaceObject.footerLogo
  }, /*#__PURE__*/react.createElement(Atlantic, {
    className: Footer_namespaceObject.footerLogoIcon
  }))), /*#__PURE__*/react.createElement("div", {
    className: Footer_namespaceObject.footerCopyright
  }, "\xA9 ", new Date().getFullYear(), " London, UK"), /*#__PURE__*/react.createElement("div", null)));
};

;// CONCATENATED MODULE: ./src/pages/Home/Home.tsx






var PageHome = function PageHome(props) {
  var resourceStringsBody = resourceStrings[props.language];
  return /*#__PURE__*/react.createElement(react.Fragment, null, /*#__PURE__*/react.createElement(Helmet/* Helmet */.S, null, /*#__PURE__*/react.createElement("html", {
    lang: props.language
  }), /*#__PURE__*/react.createElement("title", null, "Atlantic Blue - Software Development Solutions")), /*#__PURE__*/react.createElement(Header, null), /*#__PURE__*/react.createElement(Body, {
    resourceStrings: resourceStringsBody.home
  }), /*#__PURE__*/react.createElement(Footer, null));
};

;// CONCATENATED MODULE: ./src/app/main.tsx






var languages = Object.keys(ResourceStringLanguage);
var App = function App() {
  var config = useConfig();
  return /*#__PURE__*/react.createElement(dist.Routes, null, /*#__PURE__*/react.createElement(dist.Route, {
    path: "/help",
    element: /*#__PURE__*/react.createElement(Help, null)
  }), languages.map(function (key) {
    return /*#__PURE__*/react.createElement(dist.Route, {
      path: "/".concat(ResourceStringLanguage[key]),
      element: /*#__PURE__*/react.createElement(PageHome, {
        language: ResourceStringLanguage[key]
      })
    });
  }), /*#__PURE__*/react.createElement(dist.Route, {
    path: "*",
    element: /*#__PURE__*/react.createElement(PageHome, {
      language: ResourceStringLanguage.ENGLISH
    })
  }));
};
/* harmony default export */ const main = (App);
;// CONCATENATED MODULE: ./src/server/render.tsx
function render_typeof(o) { "@babel/helpers - typeof"; return render_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, render_typeof(o); }
function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return e; }; var t, e = {}, r = Object.prototype, n = r.hasOwnProperty, o = Object.defineProperty || function (t, e, r) { t[e] = r.value; }, i = "function" == typeof Symbol ? Symbol : {}, a = i.iterator || "@@iterator", c = i.asyncIterator || "@@asyncIterator", u = i.toStringTag || "@@toStringTag"; function define(t, e, r) { return Object.defineProperty(t, e, { value: r, enumerable: !0, configurable: !0, writable: !0 }), t[e]; } try { define({}, ""); } catch (t) { define = function define(t, e, r) { return t[e] = r; }; } function wrap(t, e, r, n) { var i = e && e.prototype instanceof Generator ? e : Generator, a = Object.create(i.prototype), c = new Context(n || []); return o(a, "_invoke", { value: makeInvokeMethod(t, r, c) }), a; } function tryCatch(t, e, r) { try { return { type: "normal", arg: t.call(e, r) }; } catch (t) { return { type: "throw", arg: t }; } } e.wrap = wrap; var h = "suspendedStart", l = "suspendedYield", f = "executing", s = "completed", y = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var p = {}; define(p, a, function () { return this; }); var d = Object.getPrototypeOf, v = d && d(d(values([]))); v && v !== r && n.call(v, a) && (p = v); var g = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(p); function defineIteratorMethods(t) { ["next", "throw", "return"].forEach(function (e) { define(t, e, function (t) { return this._invoke(e, t); }); }); } function AsyncIterator(t, e) { function invoke(r, o, i, a) { var c = tryCatch(t[r], t, o); if ("throw" !== c.type) { var u = c.arg, h = u.value; return h && "object" == render_typeof(h) && n.call(h, "__await") ? e.resolve(h.__await).then(function (t) { invoke("next", t, i, a); }, function (t) { invoke("throw", t, i, a); }) : e.resolve(h).then(function (t) { u.value = t, i(u); }, function (t) { return invoke("throw", t, i, a); }); } a(c.arg); } var r; o(this, "_invoke", { value: function value(t, n) { function callInvokeWithMethodAndArg() { return new e(function (e, r) { invoke(t, n, e, r); }); } return r = r ? r.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(e, r, n) { var o = h; return function (i, a) { if (o === f) throw new Error("Generator is already running"); if (o === s) { if ("throw" === i) throw a; return { value: t, done: !0 }; } for (n.method = i, n.arg = a;;) { var c = n.delegate; if (c) { var u = maybeInvokeDelegate(c, n); if (u) { if (u === y) continue; return u; } } if ("next" === n.method) n.sent = n._sent = n.arg;else if ("throw" === n.method) { if (o === h) throw o = s, n.arg; n.dispatchException(n.arg); } else "return" === n.method && n.abrupt("return", n.arg); o = f; var p = tryCatch(e, r, n); if ("normal" === p.type) { if (o = n.done ? s : l, p.arg === y) continue; return { value: p.arg, done: n.done }; } "throw" === p.type && (o = s, n.method = "throw", n.arg = p.arg); } }; } function maybeInvokeDelegate(e, r) { var n = r.method, o = e.iterator[n]; if (o === t) return r.delegate = null, "throw" === n && e.iterator["return"] && (r.method = "return", r.arg = t, maybeInvokeDelegate(e, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), y; var i = tryCatch(o, e.iterator, r.arg); if ("throw" === i.type) return r.method = "throw", r.arg = i.arg, r.delegate = null, y; var a = i.arg; return a ? a.done ? (r[e.resultName] = a.value, r.next = e.nextLoc, "return" !== r.method && (r.method = "next", r.arg = t), r.delegate = null, y) : a : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, y); } function pushTryEntry(t) { var e = { tryLoc: t[0] }; 1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e); } function resetTryEntry(t) { var e = t.completion || {}; e.type = "normal", delete e.arg, t.completion = e; } function Context(t) { this.tryEntries = [{ tryLoc: "root" }], t.forEach(pushTryEntry, this), this.reset(!0); } function values(e) { if (e || "" === e) { var r = e[a]; if (r) return r.call(e); if ("function" == typeof e.next) return e; if (!isNaN(e.length)) { var o = -1, i = function next() { for (; ++o < e.length;) if (n.call(e, o)) return next.value = e[o], next.done = !1, next; return next.value = t, next.done = !0, next; }; return i.next = i; } } throw new TypeError(render_typeof(e) + " is not iterable"); } return GeneratorFunction.prototype = GeneratorFunctionPrototype, o(g, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), o(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, u, "GeneratorFunction"), e.isGeneratorFunction = function (t) { var e = "function" == typeof t && t.constructor; return !!e && (e === GeneratorFunction || "GeneratorFunction" === (e.displayName || e.name)); }, e.mark = function (t) { return Object.setPrototypeOf ? Object.setPrototypeOf(t, GeneratorFunctionPrototype) : (t.__proto__ = GeneratorFunctionPrototype, define(t, u, "GeneratorFunction")), t.prototype = Object.create(g), t; }, e.awrap = function (t) { return { __await: t }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, c, function () { return this; }), e.AsyncIterator = AsyncIterator, e.async = function (t, r, n, o, i) { void 0 === i && (i = Promise); var a = new AsyncIterator(wrap(t, r, n, o), i); return e.isGeneratorFunction(r) ? a : a.next().then(function (t) { return t.done ? t.value : a.next(); }); }, defineIteratorMethods(g), define(g, u, "Generator"), define(g, a, function () { return this; }), define(g, "toString", function () { return "[object Generator]"; }), e.keys = function (t) { var e = Object(t), r = []; for (var n in e) r.push(n); return r.reverse(), function next() { for (; r.length;) { var t = r.pop(); if (t in e) return next.value = t, next.done = !1, next; } return next.done = !0, next; }; }, e.values = values, Context.prototype = { constructor: Context, reset: function reset(e) { if (this.prev = 0, this.next = 0, this.sent = this._sent = t, this.done = !1, this.delegate = null, this.method = "next", this.arg = t, this.tryEntries.forEach(resetTryEntry), !e) for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = t); }, stop: function stop() { this.done = !0; var t = this.tryEntries[0].completion; if ("throw" === t.type) throw t.arg; return this.rval; }, dispatchException: function dispatchException(e) { if (this.done) throw e; var r = this; function handle(n, o) { return a.type = "throw", a.arg = e, r.next = n, o && (r.method = "next", r.arg = t), !!o; } for (var o = this.tryEntries.length - 1; o >= 0; --o) { var i = this.tryEntries[o], a = i.completion; if ("root" === i.tryLoc) return handle("end"); if (i.tryLoc <= this.prev) { var c = n.call(i, "catchLoc"), u = n.call(i, "finallyLoc"); if (c && u) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } else if (c) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); } else { if (!u) throw new Error("try statement without catch or finally"); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } } } }, abrupt: function abrupt(t, e) { for (var r = this.tryEntries.length - 1; r >= 0; --r) { var o = this.tryEntries[r]; if (o.tryLoc <= this.prev && n.call(o, "finallyLoc") && this.prev < o.finallyLoc) { var i = o; break; } } i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null); var a = i ? i.completion : {}; return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, y) : this.complete(a); }, complete: function complete(t, e) { if ("throw" === t.type) throw t.arg; return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), y; }, finish: function finish(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), resetTryEntry(r), y; } }, "catch": function _catch(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.tryLoc === t) { var n = r.completion; if ("throw" === n.type) { var o = n.arg; resetTryEntry(r); } return o; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(e, r, n) { return this.delegate = { iterator: values(e), resultName: r, nextLoc: n }, "next" === this.method && (this.arg = t), y; } }, e; }
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }
function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }






var render = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee(event, assets) {
    var body, helmet, head;
    return _regeneratorRuntime().wrap(function _callee$(_context) {
      while (1) switch (_context.prev = _context.next) {
        case 0:
          body = (0,server_node/* renderToString */.iC)( /*#__PURE__*/react.createElement(server/* StaticRouter */.ws, {
            location: event.rawPath
          }, /*#__PURE__*/react.createElement(main, null)));
          helmet = Helmet/* Helmet */.S.renderStatic();
          head = "\n        <meta charset=\"utf-8\">\n        <meta name=\"viewport\" content=\"minimum-scale=1, initial-scale=1, width=device-width\" />\n        ".concat(helmet.title.toString(), "\n        ").concat(helmet.meta.toString(), "\n        ").concat(helmet.link.toString(), "\n\n        ").concat(assets.styles.map(function (filename) {
            return "<link rel=\"stylesheet\" href=\"/".concat(filename, "\" />");
          }).join('\n'), "\n        ").concat(assets.scripts.map(function (filename) {
            return "<script src=\"/".concat(filename, "\"></script>");
          }).join('\n'), "\n    ");
          return _context.abrupt("return", Html({
            head: head,
            body: body,
            htmlAttributes: helmet.htmlAttributes.toString(),
            bodyAttributes: helmet.bodyAttributes.toString()
          }));
        case 4:
        case "end":
          return _context.stop();
      }
    }, _callee);
  }));
  return function render(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();
/* harmony default export */ const server_render = (render);
;// CONCATENATED MODULE: ./src/server/lambdaHandler.ts
function lambdaHandler_typeof(o) { "@babel/helpers - typeof"; return lambdaHandler_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, lambdaHandler_typeof(o); }
function lambdaHandler_regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ lambdaHandler_regeneratorRuntime = function _regeneratorRuntime() { return e; }; var t, e = {}, r = Object.prototype, n = r.hasOwnProperty, o = Object.defineProperty || function (t, e, r) { t[e] = r.value; }, i = "function" == typeof Symbol ? Symbol : {}, a = i.iterator || "@@iterator", c = i.asyncIterator || "@@asyncIterator", u = i.toStringTag || "@@toStringTag"; function define(t, e, r) { return Object.defineProperty(t, e, { value: r, enumerable: !0, configurable: !0, writable: !0 }), t[e]; } try { define({}, ""); } catch (t) { define = function define(t, e, r) { return t[e] = r; }; } function wrap(t, e, r, n) { var i = e && e.prototype instanceof Generator ? e : Generator, a = Object.create(i.prototype), c = new Context(n || []); return o(a, "_invoke", { value: makeInvokeMethod(t, r, c) }), a; } function tryCatch(t, e, r) { try { return { type: "normal", arg: t.call(e, r) }; } catch (t) { return { type: "throw", arg: t }; } } e.wrap = wrap; var h = "suspendedStart", l = "suspendedYield", f = "executing", s = "completed", y = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var p = {}; define(p, a, function () { return this; }); var d = Object.getPrototypeOf, v = d && d(d(values([]))); v && v !== r && n.call(v, a) && (p = v); var g = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(p); function defineIteratorMethods(t) { ["next", "throw", "return"].forEach(function (e) { define(t, e, function (t) { return this._invoke(e, t); }); }); } function AsyncIterator(t, e) { function invoke(r, o, i, a) { var c = tryCatch(t[r], t, o); if ("throw" !== c.type) { var u = c.arg, h = u.value; return h && "object" == lambdaHandler_typeof(h) && n.call(h, "__await") ? e.resolve(h.__await).then(function (t) { invoke("next", t, i, a); }, function (t) { invoke("throw", t, i, a); }) : e.resolve(h).then(function (t) { u.value = t, i(u); }, function (t) { return invoke("throw", t, i, a); }); } a(c.arg); } var r; o(this, "_invoke", { value: function value(t, n) { function callInvokeWithMethodAndArg() { return new e(function (e, r) { invoke(t, n, e, r); }); } return r = r ? r.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(e, r, n) { var o = h; return function (i, a) { if (o === f) throw new Error("Generator is already running"); if (o === s) { if ("throw" === i) throw a; return { value: t, done: !0 }; } for (n.method = i, n.arg = a;;) { var c = n.delegate; if (c) { var u = maybeInvokeDelegate(c, n); if (u) { if (u === y) continue; return u; } } if ("next" === n.method) n.sent = n._sent = n.arg;else if ("throw" === n.method) { if (o === h) throw o = s, n.arg; n.dispatchException(n.arg); } else "return" === n.method && n.abrupt("return", n.arg); o = f; var p = tryCatch(e, r, n); if ("normal" === p.type) { if (o = n.done ? s : l, p.arg === y) continue; return { value: p.arg, done: n.done }; } "throw" === p.type && (o = s, n.method = "throw", n.arg = p.arg); } }; } function maybeInvokeDelegate(e, r) { var n = r.method, o = e.iterator[n]; if (o === t) return r.delegate = null, "throw" === n && e.iterator["return"] && (r.method = "return", r.arg = t, maybeInvokeDelegate(e, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), y; var i = tryCatch(o, e.iterator, r.arg); if ("throw" === i.type) return r.method = "throw", r.arg = i.arg, r.delegate = null, y; var a = i.arg; return a ? a.done ? (r[e.resultName] = a.value, r.next = e.nextLoc, "return" !== r.method && (r.method = "next", r.arg = t), r.delegate = null, y) : a : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, y); } function pushTryEntry(t) { var e = { tryLoc: t[0] }; 1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e); } function resetTryEntry(t) { var e = t.completion || {}; e.type = "normal", delete e.arg, t.completion = e; } function Context(t) { this.tryEntries = [{ tryLoc: "root" }], t.forEach(pushTryEntry, this), this.reset(!0); } function values(e) { if (e || "" === e) { var r = e[a]; if (r) return r.call(e); if ("function" == typeof e.next) return e; if (!isNaN(e.length)) { var o = -1, i = function next() { for (; ++o < e.length;) if (n.call(e, o)) return next.value = e[o], next.done = !1, next; return next.value = t, next.done = !0, next; }; return i.next = i; } } throw new TypeError(lambdaHandler_typeof(e) + " is not iterable"); } return GeneratorFunction.prototype = GeneratorFunctionPrototype, o(g, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), o(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, u, "GeneratorFunction"), e.isGeneratorFunction = function (t) { var e = "function" == typeof t && t.constructor; return !!e && (e === GeneratorFunction || "GeneratorFunction" === (e.displayName || e.name)); }, e.mark = function (t) { return Object.setPrototypeOf ? Object.setPrototypeOf(t, GeneratorFunctionPrototype) : (t.__proto__ = GeneratorFunctionPrototype, define(t, u, "GeneratorFunction")), t.prototype = Object.create(g), t; }, e.awrap = function (t) { return { __await: t }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, c, function () { return this; }), e.AsyncIterator = AsyncIterator, e.async = function (t, r, n, o, i) { void 0 === i && (i = Promise); var a = new AsyncIterator(wrap(t, r, n, o), i); return e.isGeneratorFunction(r) ? a : a.next().then(function (t) { return t.done ? t.value : a.next(); }); }, defineIteratorMethods(g), define(g, u, "Generator"), define(g, a, function () { return this; }), define(g, "toString", function () { return "[object Generator]"; }), e.keys = function (t) { var e = Object(t), r = []; for (var n in e) r.push(n); return r.reverse(), function next() { for (; r.length;) { var t = r.pop(); if (t in e) return next.value = t, next.done = !1, next; } return next.done = !0, next; }; }, e.values = values, Context.prototype = { constructor: Context, reset: function reset(e) { if (this.prev = 0, this.next = 0, this.sent = this._sent = t, this.done = !1, this.delegate = null, this.method = "next", this.arg = t, this.tryEntries.forEach(resetTryEntry), !e) for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = t); }, stop: function stop() { this.done = !0; var t = this.tryEntries[0].completion; if ("throw" === t.type) throw t.arg; return this.rval; }, dispatchException: function dispatchException(e) { if (this.done) throw e; var r = this; function handle(n, o) { return a.type = "throw", a.arg = e, r.next = n, o && (r.method = "next", r.arg = t), !!o; } for (var o = this.tryEntries.length - 1; o >= 0; --o) { var i = this.tryEntries[o], a = i.completion; if ("root" === i.tryLoc) return handle("end"); if (i.tryLoc <= this.prev) { var c = n.call(i, "catchLoc"), u = n.call(i, "finallyLoc"); if (c && u) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } else if (c) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); } else { if (!u) throw new Error("try statement without catch or finally"); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } } } }, abrupt: function abrupt(t, e) { for (var r = this.tryEntries.length - 1; r >= 0; --r) { var o = this.tryEntries[r]; if (o.tryLoc <= this.prev && n.call(o, "finallyLoc") && this.prev < o.finallyLoc) { var i = o; break; } } i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null); var a = i ? i.completion : {}; return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, y) : this.complete(a); }, complete: function complete(t, e) { if ("throw" === t.type) throw t.arg; return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), y; }, finish: function finish(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), resetTryEntry(r), y; } }, "catch": function _catch(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.tryLoc === t) { var n = r.completion; if ("throw" === n.type) { var o = n.arg; resetTryEntry(r); } return o; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(e, r, n) { return this.delegate = { iterator: values(e), resultName: r, nextLoc: n }, "next" === this.method && (this.arg = t), y; } }, e; }
function lambdaHandler_asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }
function lambdaHandler_asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { lambdaHandler_asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { lambdaHandler_asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

var createBody = /*#__PURE__*/function () {
  var _ref = lambdaHandler_asyncToGenerator( /*#__PURE__*/lambdaHandler_regeneratorRuntime().mark(function _callee(event) {
    var assets;
    return lambdaHandler_regeneratorRuntime().wrap(function _callee$(_context) {
      while (1) switch (_context.prev = _context.next) {
        case 0:
          _context.next = 2;
          return __webpack_require__.e(/* import() */ 932).then(__webpack_require__.t.bind(__webpack_require__, "./dist/stats.json", 19));
        case 2:
          assets = _context.sent["default"];
          return _context.abrupt("return", server_render(event, assets));
        case 4:
        case "end":
          return _context.stop();
      }
    }, _callee);
  }));
  return function createBody(_x) {
    return _ref.apply(this, arguments);
  };
}();
var lambdaHandler = /*#__PURE__*/function () {
  var _ref2 = lambdaHandler_asyncToGenerator( /*#__PURE__*/lambdaHandler_regeneratorRuntime().mark(function _callee2(event) {
    return lambdaHandler_regeneratorRuntime().wrap(function _callee2$(_context2) {
      while (1) switch (_context2.prev = _context2.next) {
        case 0:
          _context2.prev = 0;
          _context2.t0 = {
            "Content-Type": "text/html"
          };
          _context2.next = 4;
          return createBody(event);
        case 4:
          _context2.t1 = _context2.sent;
          return _context2.abrupt("return", {
            statusCode: 200,
            headers: _context2.t0,
            body: _context2.t1
          });
        case 8:
          _context2.prev = 8;
          _context2.t2 = _context2["catch"](0);
          // Custom error handling for server-side errors
          console.error(_context2.t2);
          return _context2.abrupt("return", {
            statusCode: 500,
            headers: {
              "Content-Type": "text/html"
            },
            body: "<html><body>".concat(_context2.t2 === null || _context2.t2 === void 0 ? void 0 : _context2.t2.toString(), "</body></html>")
          });
        case 12:
        case "end":
          return _context2.stop();
      }
    }, _callee2, null, [[0, 8]]);
  }));
  return function lambdaHandler(_x2) {
    return _ref2.apply(this, arguments);
  };
}();


/***/ })

};
;
//# sourceMappingURL=chunk.320.9f32cd126504e2703147.js.map