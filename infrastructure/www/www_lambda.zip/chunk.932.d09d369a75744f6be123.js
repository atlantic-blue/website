"use strict";
exports.id = 932;
exports.ids = [932];
exports.modules = {

/***/ "./dist/stats.json":
/***/ ((module) => {

module.exports = /*#__PURE__*/JSON.parse('{"scripts":["main.9796f9f4.js","runtime.d94e1a3c.js","vendor.08610145.js","components.6c52d585.js","pages.82e1c958.js"],"styles":["main.088064b5.css","components.b00cfce2.css","pages.e86b6caf.css"]}');

/***/ })

};
;