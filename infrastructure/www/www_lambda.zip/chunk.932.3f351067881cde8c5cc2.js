"use strict";
exports.id = 932;
exports.ids = [932];
exports.modules = {

/***/ "./dist/stats.json":
/***/ ((module) => {

module.exports = /*#__PURE__*/JSON.parse('{"scripts":["main.f8a2fd93.js","runtime.ca3bb55a.js","vendor.da41ab1d.js","components.0722e36c.js","pages.2c159077.js"],"styles":[]}');

/***/ })

};
;