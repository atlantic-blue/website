"use strict";
exports.id = 688;
exports.ids = [688];
exports.modules = {

/***/ "./dist/public/stats.json":
/***/ ((module) => {

module.exports = /*#__PURE__*/JSON.parse('{"scripts":["public/main.8922c43c.js","public/runtime.d94e1a3c.js","public/vendor.0aa3f3f8.js","public/components.3f2edfaa.js","public/pages.b411df80.js"],"styles":["public/main.088064b5.css","public/components.b00cfce2.css","public/pages.e86b6caf.css"]}');

/***/ })

};
;