"use strict";
exports.id = 932;
exports.ids = [932];
exports.modules = {

/***/ "./dist/stats.json":
/***/ ((module) => {

module.exports = /*#__PURE__*/JSON.parse('{"scripts":["main.cbf41691.js","runtime.d94e1a3c.js","vendor.08610145.js","components.f04553d6.js","pages.0876a2ed.js"],"styles":["main.088064b5.css","components.b00cfce2.css","pages.e86b6caf.css"]}');

/***/ })

};
;