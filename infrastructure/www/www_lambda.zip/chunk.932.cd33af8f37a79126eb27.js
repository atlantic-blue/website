"use strict";
exports.id = 932;
exports.ids = [932];
exports.modules = {

/***/ "./dist/stats.json":
/***/ ((module) => {

module.exports = /*#__PURE__*/JSON.parse('{"scripts":["main.73099474.js","runtime.1a9dd876.js","vendor.d79eef50.js","components.7332c47a.js","pages.cf1f4ec0.js"],"styles":["components.8f6ec754.css","pages.84b0ae8d.css"]}');

/***/ })

};
;