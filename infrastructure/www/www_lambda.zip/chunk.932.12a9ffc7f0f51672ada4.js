"use strict";
exports.id = 932;
exports.ids = [932];
exports.modules = {

/***/ "./dist/stats.json":
/***/ ((module) => {

module.exports = /*#__PURE__*/JSON.parse('{"scripts":["main.ae93aff0.js","runtime.1b451e2d.js","vendor.a30dc914.js","components.276cfce0.js","pages.0119c20f.js"],"styles":["main.3d402c9d.css","components.8f6ec754.css","pages.84b0ae8d.css"]}');

/***/ })

};
;